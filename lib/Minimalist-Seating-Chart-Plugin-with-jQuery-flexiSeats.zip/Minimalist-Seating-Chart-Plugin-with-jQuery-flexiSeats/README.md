# flexiSeats
Create flexible seating layouts with an efficient jQuery plugin

/* Documentation under construction */
